package com.example.companymicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanymicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
