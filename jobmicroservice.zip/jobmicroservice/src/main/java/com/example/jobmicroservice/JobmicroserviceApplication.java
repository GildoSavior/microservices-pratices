package com.example.jobmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobmicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobmicroserviceApplication.class, args);
	}

}
