package com.example.reviewmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewmicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewmicroserviceApplication.class, args);
	}

}
