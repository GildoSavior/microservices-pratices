package com.example.reviewmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewmicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
